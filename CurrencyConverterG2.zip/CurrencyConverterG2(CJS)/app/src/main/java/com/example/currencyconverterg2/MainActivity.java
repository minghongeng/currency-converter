package com.example.currencyconverterg2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    // can replace the 3 buttons with spinner with radio button for extra marks and uniqueness

    // if the user click convert to USD button
    public void convert(View view)
    {
        // get the textbox from the res folder, xml file
        // get the input value from the textbox, convert to string, then convert to double
        // run some animation effect on the textbox, change the alpha leve, resize the textbox
        // do the calculations
        // display the result on the toast dialog box

        EditText dollarField = (EditText) findViewById(R.id.dollarField);
        Double dollarAmount = Double.parseDouble(dollarField.getText().toString());

        dollarField.animate().alpha(0).setDuration(2000); // make it transparent 2000ms
        dollarField.animate().x(500).setDuration(2000);
        dollarField.animate().scaleX(0.5f).setDuration(2000); // make it bigger 2000ms

        Double usdAmount = dollarAmount * 0.24; // do the calculations

        // display the result
        Toast.makeText(getApplicationContext(),
                "USD $" + usdAmount.toString(), Toast.LENGTH_LONG).show();
    }

    // if the user click convert to pound sterling button
    public void convert2(View view)
    {

        EditText dollarField = (EditText) findViewById(R.id.dollarField);
        Double dollarAmount = Double.parseDouble(dollarField.getText().toString());

        dollarField.animate().alpha(0).setDuration(2000); // make it transparent 2000ms
        dollarField.animate().x(500).setDuration(2000);
        dollarField.animate().scaleX(0.5f).setDuration(2000); // make it bigger 2000ms

        Double poundAmount = dollarAmount * 0.18; // change the rate later, not 0.24

        // display the result
        Toast.makeText(getApplicationContext(),
                "GBP £" + poundAmount.toString(), Toast.LENGTH_LONG).show();
    }


    // if the user click convert to singapore dollar button
    public void convert3(View view)
    {
        EditText dollarField = (EditText) findViewById(R.id.dollarField);
        Double dollarAmount = Double.parseDouble(dollarField.getText().toString());

        dollarField.animate().alpha(0).setDuration(2000); // make it transparent 2000ms
        dollarField.animate().x(500).setDuration(2000);
        dollarField.animate().scaleX(0.5f).setDuration(2000); // make it bigger 2000ms

        Double SGDAmount = dollarAmount * 0.33; // change later, not 0.24

        // display the result
        Toast.makeText(getApplicationContext(),
                "SGD S$" + SGDAmount.toString(), Toast.LENGTH_LONG).show();
    }

}
